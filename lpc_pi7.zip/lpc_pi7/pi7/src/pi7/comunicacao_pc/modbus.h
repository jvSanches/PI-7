#ifndef __modbus_h
#define __modbus_h

extern void com_executeCommunication();
extern void com_init();

#endif
